//
//  AppDelegate.swift
//  ChatApp
//
//  Created by vamsi on 08/02/20.
//  Copyright © 2020 vamsi. All rights reserved.
//

import UIKit
import Firebase
import IQKeyboardManagerSwift

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        FirebaseApp.configure()
        Database.database().isPersistenceEnabled = true
        IQKeyboardManager.shared.enable = true
        IQKeyboardManager.shared.enableAutoToolbar = false
        if let _ = Auth.auth().currentUser {
            self.window = UIWindow(frame: UIScreen.main.bounds)
            let tabViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
            let tabNav = UINavigationController(rootViewController: tabViewController)
            tabNav.isNavigationBarHidden = true
            self.window?.rootViewController = tabNav
            self.window?.makeKeyAndVisible()
        }
        return true
    }
    
    
}

