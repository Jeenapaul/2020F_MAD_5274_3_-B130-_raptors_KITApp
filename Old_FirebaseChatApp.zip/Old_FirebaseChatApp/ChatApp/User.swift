//
//  User.swift
//  ChatApp
//
//  Created by vamsi on 08/02/20.
//  Copyright © 2020 vamsi. All rights reserved.
//

import Foundation

class User:Codable {
    var name = ""
    var email = ""
    var profilePic = ""
    var uid = ""
    var password:String?
    var sendTime:Double?
}
