//
//  UsersTableViewCell.swift
//  ChatApp
//
//  Created by vamsi on 08/02/20.
//  Copyright © 2020 vamsi. All rights reserved.
//

import UIKit
import SDWebImage

class UsersTableViewCell: UITableViewCell {
    
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var profilePic: UIImageView!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func setupCell(with user:User){
        userNameLabel.text = user.name
        emailLabel.text = user.email
        if user.profilePic.isNotEmpty{
            let url = URL(string: user.profilePic)
            profilePic.sd_setImage(with: url, completed: nil)
        }
    }
    
    func configure(message:Messages){
        emailLabel.text = message.text
        let time = message.sendTime!
        let date = Date(timeIntervalSince1970: time)
        let dateFormatter = DateFormatter.defaultDateFormatter(.monthDateTimeWithout)
        timeLabel.text = dateFormatter.string(from: date)
        
        
        let chatPartnerId: String?
        
        if message.fromId == getCurrentUId {
            chatPartnerId = message.toId
        } else {
            chatPartnerId = message.fromId
        }
        
        
        if let id = chatPartnerId{
            FirReference.usersRef.child(id).observeSingleEvent(of: .value) { (snapshot) in
                if let dictionary = snapshot.value as? [String:AnyObject]{
                    self.userNameLabel.text = dictionary["name"] as? String
                    let profileImageUrl = dictionary["profilePic"] as? String
                    self.profilePic.isHidden = false
                    if let profile = profileImageUrl{
                        let url = URL(string: profile)
                        self.profilePic.sd_setImage(with: url, completed: nil)
                    }else{
                        self.profilePic.isHidden = true
                    }
                }
            }
            
        }
    }
    
}
