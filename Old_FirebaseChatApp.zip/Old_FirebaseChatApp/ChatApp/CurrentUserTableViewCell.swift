//
//  ChatTableViewCell.swift
//  ChatApp
//
//  Created by vamsi on 09/02/20.
//  Copyright © 2020 vamsi. All rights reserved.
//

import UIKit
import Lightbox


class CurrentUserTableViewCell: UITableViewCell {
    
    @IBOutlet weak var imgViewTop: NSLayoutConstraint!
    @IBOutlet weak var imgViewHeight: NSLayoutConstraint!
    @IBOutlet weak var uploadedImgView: UIImageView!
    @IBOutlet weak var messageLbl: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var containerView: UIView!

    
    var parentVC:UIViewController?
    let blueColor = UIColor(red: 0/255, green: 142/255, blue: 246/255, alpha: 1)
    
    override func awakeFromNib() {
        super.awakeFromNib()
        let tap = UITapGestureRecognizer(target: self, action: #selector(open))
        uploadedImgView.addGestureRecognizer(tap)
        uploadedImgView.isUserInteractionEnabled = true
    }
 
    func configureCell(_ message:Messages){
        containerView.backgroundColor = blueColor
        messageLbl.text = message.text ?? ""
        let time = message.sendTime ?? 0.0
        let date = Date(timeIntervalSince1970: time)
        let dateFormatter = DateFormatter.defaultDateFormatter(.monthDateTimeWithout)
        timeLabel.text = dateFormatter.string(from: date)
        if let url = URL(string: message.imageUrl ?? ""){
            imgViewTop.constant = 5
            uploadedImgView.isHidden = false
            imgViewHeight.constant = 130
            uploadedImgView.sd_setImage(with: url)
        }else{
            imgViewTop.constant = 0
            uploadedImgView.isHidden = true
            imgViewHeight.constant = 0
        }
    }
    
    
    @objc func open(tapGestureRecognizer: UITapGestureRecognizer){
        let tappedImage = tapGestureRecognizer.view as! UIImageView
        var images: [LightboxImage] = []
        images.append(LightboxImage(image: tappedImage.image ?? UIImage()))
        // Create an instance of LightboxController.
        let controller = LightboxController(images: images)
        controller.modalPresentationStyle = .fullScreen
        // Set delegates.
        controller.pageDelegate = self
        controller.dismissalDelegate = self
        // Use dynamic background.
        controller.dynamicBackground = true
        parentVC?.present(controller, animated: true, completion: nil)
    }
    
}


extension CurrentUserTableViewCell: LightboxControllerPageDelegate, LightboxControllerDismissalDelegate {
    func lightboxController(_ controller: LightboxController, didMoveToPage page: Int) {
        
    }
    
    func lightboxControllerWillDismiss(_ controller: LightboxController) {
        
    }
    
}


extension CurrentUserTableViewCell: LightboxControllerTouchDelegate{
    func lightboxController(_ controller: LightboxController, didTouch image: LightboxImage, at index: Int) {
    }
}


