//
//  Messages.swift
//  FirebaseChatApp
//
//  Created by vamsi on 18/04/19.
//  Copyright © 2019 vamshi krishna. All rights reserved.
//

import Foundation
class Messages:Codable {
    
    var fromId:String?
    var name:String?
    var sendTime:Double?
    var toId:String?
    var text:String?
    var imageUrl:String?
    var messageId:String?
    
    var chatPartnerId:String?{
        return fromId == getCurrentUId ? toId : fromId
    }

}
