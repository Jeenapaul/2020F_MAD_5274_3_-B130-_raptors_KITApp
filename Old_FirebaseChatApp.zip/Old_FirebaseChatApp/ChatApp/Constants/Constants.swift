//
//  Constants.swift
//  ChatApp
//
//  Created by vamsi on 08/02/20.
//  Copyright © 2020 vamsi. All rights reserved.
//

import Foundation
import Firebase


struct FirReference {
    static let mainRef =   Database.database().reference()
    static let usersRef =   mainRef.child("Users")
    static var userMessages = mainRef.child("user-messages")
    static var messages = mainRef.child("messages")
    
}
var getCurrentUId:String{
    return Auth.auth().currentUser!.uid
}
