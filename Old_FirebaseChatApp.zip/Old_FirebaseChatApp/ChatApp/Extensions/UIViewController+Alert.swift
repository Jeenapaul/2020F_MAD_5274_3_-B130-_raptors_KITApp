//
//  UISearchBar.swift
//  ProjectTemplate
//
//  Created by vamsi on 02/02/20.
//  Copyright © 2020 vamsi. All rights reserved.
//

import UIKit

extension UIViewController{
    func showAlert(withMessage message: String? = nil, title: String = "Alert", okayTitle: String = "Ok", cancelTitle: String? = nil,preferredStyle:UIAlertController.Style = .alert , okCall: @escaping () -> () = { }, cancelCall: @escaping () -> () = { }) {
    let alert = UIAlertController(title: title, message: message, preferredStyle: preferredStyle)
    if let cancelTitle = cancelTitle {
        let cancelAction = UIAlertAction(title: cancelTitle, style: .cancel) { (_) in
            cancelCall()
        }
        alert.addAction(cancelAction)
    }
    let okayAction = UIAlertAction(title: okayTitle, style: .default) { (_) in
        okCall()
    }
    alert.addAction(okayAction)
    present(alert, animated: true)
}
}
