//
//  UIView+LiveRendering.swift
//  ProjectTemplate
//
//  Created by vamsi on 02/02/20.
//  Copyright © 2020 vamsi. All rights reserved.
//

import Foundation
import UIKit

extension UIDevice {
    enum DeviceType: String {
        case iPhone4_4S = "iPhone 4 or iPhone 4S"
        case iPhones_5_5s_5c_SE = "iPhone 5, iPhone 5s, iPhone 5c or iPhone SE"
        case iPhones_6_6s_7_8 = "iPhone 6, iPhone 6S, iPhone 7 or iPhone 8"
        case iPhones_6Plus_6sPlus_7Plus_8Plus = "iPhone 6 Plus, iPhone 6S Plus, iPhone 7 Plus or iPhone 8 Plus"
        case iPhoneX_iPhoneXs = "iPhone X or iPhoneXs"
        case iPhoneXR = "iPhone XR"
        case iPhoneXsMax = "iPhone XsMax"
        case ipad = "ipad"
        case unknown = "iPadOrUnknown"
    }
    var deviceType: DeviceType {
        switch UIScreen.main.nativeBounds.height {
        case 960:
            return .iPhone4_4S
        case 1136:
            return .iPhones_5_5s_5c_SE
        case 1334:
            return .iPhones_6_6s_7_8
        case 1920, 2208:
            return .iPhones_6Plus_6sPlus_7Plus_8Plus
        case 1792:
            return .iPhoneXR
        case 2436:
            return .iPhoneX_iPhoneXs
        case 2688:
            return .iPhoneXsMax
        case 1024:
            return .ipad
        default:
            return .unknown
        }
    }
}

