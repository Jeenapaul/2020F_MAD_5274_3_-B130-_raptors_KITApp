//
//  Thumbnail.swift
//  Exactech
//
//  Created by Quventix Solutions on 17/09/19.
//  Copyright © 2019 vamsi. All rights reserved.
//

import UIKit

extension String{
    var isVideoUrl:Bool{
        return contains(".mp4") || contains(".MP4") || contains(".MOV") || contains("Video") ? true : false
    }
}

extension String{
    var url:URL{
       return URL(string: self)!
    }
}

extension String{
    var int:Int{
        return Int(self) ?? 0
    }
}
