//
//  String+SubScript.swift
//  Liscio
//
//  Created by Tejinder Paul Singh  on 14/04/18.
//  Copyright © 2018 HungryHub. All rights reserved.
//

import Foundation
import UIKit
extension String{
    func convertDateFormatter() -> String {
        let dateFormatter = DateFormatter()
        let gregorianCalendar = NSCalendar(calendarIdentifier: NSCalendar.Identifier.gregorian)!
        dateFormatter.calendar = gregorianCalendar as Calendar
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        let convertedDate = dateFormatter.date(from: self)
        guard dateFormatter.date(from: self) != nil else {
            return ""
        }
        dateFormatter.dateFormat = "dd MMM yyyy"
        dateFormatter.timeZone = NSTimeZone.local
        dateFormatter.locale = Locale.current
        let timeStamp = dateFormatter.string(from: convertedDate!)
        return timeStamp
    }
}
