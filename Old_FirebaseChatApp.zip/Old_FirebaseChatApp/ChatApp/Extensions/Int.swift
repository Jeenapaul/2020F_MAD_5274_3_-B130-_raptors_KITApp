//
//  Int.swift
//  Exactech
//
//  Created by Quventix Solutions on 18/09/19.
//  Copyright © 2019 vamsi. All rights reserved.
//

import Foundation

extension Int{
    var string:String{
        return "\(self)"
    }
}
