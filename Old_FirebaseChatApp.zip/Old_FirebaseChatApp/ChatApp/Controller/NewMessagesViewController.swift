//
//  NewMessagesViewController.swift
//  ChatApp
//
//  Created by vamsi on 08/02/20.
//  Copyright © 2020 vamsi. All rights reserved.
//

import UIKit
import Firebase
import SVProgressHUD

class AllUsersViewController: UIViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    
    var usersList = [User]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.tableFooterView = .init()
        fetchUsers()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.isNavigationBarHidden = true
    }
    
    func fetchUsers(){
        SVProgressHUD.show(withStatus: "Loading...")
        FirReference.usersRef.observe(.childAdded) { (dataSnapshot) in
            guard let snapshot = dataSnapshot.value as? [String:Any] else{return}
            do{
                let data = try JSONSerialization.data(withJSONObject: snapshot, options: .fragmentsAllowed)
                let user = try JSONDecoder().decode(User.self, from: data)
                self.usersList.append(user)
                DispatchQueue.main.async {
                    SVProgressHUD.dismiss()
                    self.tableView.reloadData()
                }
            }catch{
                SVProgressHUD.dismiss()
                print(error.localizedDescription)
            }
        }
        
        
    }
    
    
    @IBAction func handleCancel(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
}

// MARK: - UITableViewDataSource

extension AllUsersViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return usersList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: UsersTableViewCell.reuseid, for: indexPath) as! UsersTableViewCell
        let user = usersList[indexPath.row]
        cell.setupCell(with: user)
        return cell
    }
}

// MARK: - UITableViewDelegate

extension AllUsersViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 85
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let chatVC:ChatViewController = UIStoryboard(storyboard: .Main, bundle: nil).controller()
        let user = usersList[indexPath.row]
        chatVC.user = user
        navigationController?.pushViewController(chatVC, animated: true)
    }
}


