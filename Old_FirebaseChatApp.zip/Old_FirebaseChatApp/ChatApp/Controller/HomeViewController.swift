//
//  MessagesViewController.swift
//  ChatApp
//
//  Created by vamsi on 08/02/20.
//  Copyright © 2020 vamsi. All rights reserved.
//

import UIKit
import Firebase
import SVProgressHUD

class HomeViewController: UIViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var profilePic: UIImageView!
    
    var window: UIWindow?
    var messagesArray = [Messages]()
    var messagesDictionary = [String: Messages]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        tableView.tableFooterView = .init()
        messagesArray.removeAll()
        messagesDictionary.removeAll()
        observeUserMessages()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.isNavigationBarHidden = true
        setupTitleView()
    }
    
    
    func observeUserMessages(){
        messagesArray.removeAll()
        SVProgressHUD.show(withStatus: "Loading messages...")
        let userId = getCurrentUId
        
        //This is only used to dismiss the loader
        FirReference.userMessages.child(userId).observeSingleEvent(of: .value) { (dataSnapshot) in
            if !dataSnapshot.exists(){
                SVProgressHUD.dismiss()
                return
            }
        }
        //
        
        
        FirReference.userMessages.child(userId).observe(.childAdded) { (dataSnapshot) in
            if !dataSnapshot.exists(){
                SVProgressHUD.dismiss()
                return
            }
            let toUser_Id = dataSnapshot.key
            
            FirReference.userMessages.child(getCurrentUId).child(toUser_Id).observe(.childRemoved) { (snapShot) in
                print(snapShot.key)
//                self.fetchMessage(dataSnapshot.key)
            }
            
            FirReference.userMessages.child(getCurrentUId).child(toUser_Id).observe(.childAdded) { (dataSnapshot) in
                if !dataSnapshot.exists(){
                    SVProgressHUD.dismiss()
                    return
                }
                self.fetchMessage(dataSnapshot.key)
            }
        }
        observeDeleteMessage()
    }
    
    func fetchMessage(_ messageId:String){
        let messagesReference = FirReference.messages.child(messageId)
        messagesReference.observe(.value) { (snapshot) in
            if !snapshot.exists(){
                SVProgressHUD.dismiss()
                return
            }
            if let dict = snapshot.value as? [String:Any]{
                if let resp = try? JSONSerialization.data(withJSONObject: dict, options: .prettyPrinted){
                    if let reactionResp = try? JSONDecoder().decode(Messages.self, from: resp){
                        if let chatPartnerId = reactionResp.chatPartnerId {
                            self.messagesDictionary[chatPartnerId] = reactionResp
                            DispatchQueue.main.async {
                                SVProgressHUD.dismiss()
                            }
                            self.reloadData()
                        }
                    }else{
                        SVProgressHUD.dismiss()
                    }
                }else{
                    SVProgressHUD.dismiss()
                }
            }else{
                SVProgressHUD.dismiss()
            }
        }
    }
    
    func observeDeleteMessage(){
        FirReference.userMessages.child(getCurrentUId).observe(.childRemoved) { (snapShot) in
            self.messagesDictionary.removeValue(forKey: snapShot.key)
            self.reloadData()
        }
    }
    
    fileprivate func setupTitleView() {
        FirReference.usersRef.child(getCurrentUId).observeSingleEvent(of: .value) { (snapshot) in
            if let user = snapshot.value as? [String:AnyObject]{
                DispatchQueue.main.async {
                    self.setupUI(data: user)
                }
            }
        }
    }
    
    func reloadData(){
        self.messagesArray = Array(self.messagesDictionary.values)
        self.messagesArray.sort{Int($0.sendTime!) > Int($1.sendTime!)}
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            self.tableView.reloadData()
        }
    }
    
    func setupUI(data:[String:AnyObject]){
        guard let userName = data["name"] as? String else{return}
        titleLabel.text = userName
        let profileImageUrl = data["profilePic"] as? String
        if let profile = profileImageUrl{
            let url = URL(string: profile)
            self.profilePic.sd_setImage(with: url, completed: nil)
        }else{
            self.profilePic.isHidden = true
        }
    }
    
    func showChatLogVC(with user:User){
        let chatVC:ChatViewController = UIStoryboard(storyboard: .Main, bundle: nil).controller()
        chatVC.user = user
        navigationController?.pushViewController(chatVC, animated: true)
    }
    
    @IBAction func handleProfileTap(_ sender: Any) {
        let profileVC:ProfileViewController = UIStoryboard(storyboard: .Main, bundle: nil).controller()
        navigationController?.pushViewController(profileVC, animated: true)
    }
    
    @IBAction func handleLogout(_ sender: Any) {
        removePresentedOrShowedVC()
    }
    
    func removePresentedOrShowedVC() {
        if let navgtnCount = self.navigationController?.children.count, navgtnCount > 1 {
            self.navigationController?.popViewController(animated: true)
            do{
                try Auth.auth().signOut()
            }catch{
                print(error.localizedDescription)
            }
        } else {
            logout()
        }
    }
    
    func logout(){
        do{
            try Auth.auth().signOut()
            self.window = UIWindow(frame: UIScreen.main.bounds)
            let signInVC = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
            let signInNav = UINavigationController(rootViewController: signInVC)
            self.window?.rootViewController = signInNav
            self.window?.makeKeyAndVisible()
        }catch{
            print("error")
        }
    }
    
    @IBAction func handleMessageBtn(_ sender: Any) {
        moveToNewMessagesVC()
    }
    
    
    func moveToNewMessagesVC(){
        let messagesVC:AllUsersViewController = UIStoryboard(storyboard: .Main, bundle: nil).controller()
        navigationController?.pushViewController(messagesVC, animated: true)
    }
}

// MARK: - UITableViewDataSource

extension HomeViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messagesArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: UsersTableViewCell.reuseid, for: indexPath) as! UsersTableViewCell
        let message = messagesArray[indexPath.row]
        cell.configure(message: message)
        return cell
    }
}

// MARK: - UITableViewDelegate

extension HomeViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 75
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let message = messagesArray[indexPath.row]
        moveToChatVC(message)
    }
    
    func moveToChatVC(_ message:Messages){
        guard let chatPartnerId = message.chatPartnerId else {
            return
        }
        let ref = FirReference.usersRef.child(chatPartnerId)
        ref.observeSingleEvent(of: .value, with: { (snapshot) in
            guard let dictionary = snapshot.value as? [String: AnyObject] else {
                return
            }
            if let resp = try? JSONSerialization.data(withJSONObject: dictionary, options: .prettyPrinted){
                if let userObj = try? JSONDecoder().decode(User.self, from: resp){
                    let user = userObj
                    user.uid = chatPartnerId
                    self.showChatLogVC(with: user)
                }
            }
        })
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            let msg = self.messagesArray[indexPath.row]
            guard let chartPartnerId = msg.chatPartnerId else{return}
            FirReference.userMessages.child(getCurrentUId).child(chartPartnerId).removeValue { (err, ref) in
                if err != nil{
                    print(err?.localizedDescription as Any)
                    return
                }
                self.messagesDictionary.removeValue(forKey: chartPartnerId)
                self.reloadData()
            }
        }
    }
}
