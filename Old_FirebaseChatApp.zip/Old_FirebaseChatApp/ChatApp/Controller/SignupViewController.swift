//
//  SignupViewController.swift
//  ChatApp
//
//  Created by vamsi on 08/02/20.
//  Copyright © 2020 vamsi. All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage
import SVProgressHUD

class SignupViewController: UIViewController {
    
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    var imagepickerVC:ReusableImagePickerController!
    var imageUrl = ""

    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleImageTap))
        profileImageView.addGestureRecognizer(tapGesture)
        setupImagePickerController()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.isNavigationBarHidden = true
        emailTextField.backgroundColor = .white
        passwordTextField.backgroundColor = .white
        nameTextField.backgroundColor = .white
    }
    
    func setupImagePickerController(){
        self.imagepickerVC = ReusableImagePickerController(controller: self)
        imagepickerVC.delegate = self
        imagepickerVC.allowsEditing = false
        imagepickerVC.sourceType = .savedPhotosAlbum
    }
    
    @objc func handleImageTap(){
        imagepickerVC.present()
    }
    
    @IBAction func signupBtnTapped(_ sender: Any) {
        
        let email = emailTextField.text?.isEmpty ?? true ? "test@gmail.com" : emailTextField.text!
        let password = passwordTextField.text?.isEmpty ?? true ? "123456" : passwordTextField.text!
        let name = nameTextField.text?.isEmpty ?? true ? "Test" : nameTextField.text!

        let createdTime = Double(Date().timeIntervalSince1970)

        Auth.auth().createUser(withEmail: email, password: password) { (result, error) in
            if error != nil{
                self.showAlert(withMessage: error?.localizedDescription)
                return
            }
            guard let user = result?.user else{return}
            let dict = [
                "name":name,
                "email":email,
                "profilePic":self.imageUrl,
                "uid":user.uid,
                "createdTime":createdTime,
                "password":password
                ] as [String : Any]
            FirReference.usersRef.child(user.uid).setValue(dict)
            self.moveToMessagesVC()
        }
    }
    
    func uploadImage(){
        guard let image = profileImageView.image else { return}
        let randomImageName =  NSUUID().uuidString
        let storageRef = Storage.storage().reference().child("\(randomImageName).png")
        guard let imageData = image.jpegData(compressionQuality: 0.1) else {return  }
        storageRef.putData(imageData, metadata: nil, completion:
            {
                (metadata, error) in
                if error != nil {
                    print(error?.localizedDescription ?? "")
                    return
                }
                storageRef.downloadURL(completion: { (url, err) in
                    if let err = err {
                        print(err.localizedDescription)
                        return
                    }
                    guard let url = url else { return }
                    SVProgressHUD.dismiss()
                    self.imageUrl = url.absoluteString
                })
        })
    }
    
    func moveToMessagesVC(){
        let messagesVC:HomeViewController = UIStoryboard(storyboard: .Main, bundle: nil).controller()
        navigationController?.pushViewController(messagesVC, animated: true)
    }
    
    @IBAction func signinBtnTapped(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
}

extension SignupViewController:ImagePickerDelegate{
    func didSelect(image: UIImage) {
        self.profileImageView.image = image
        uploadImage()
    }
}
