//
//  LoginViewController.swift
//  ChatApp
//
//  Created by vamsi on 08/02/20.
//  Copyright © 2020 vamsi. All rights reserved.
//

import UIKit
import Firebase

class LoginViewController: UIViewController {
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
        
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.isNavigationBarHidden = true
        emailTextField.backgroundColor = .white
        passwordTextField.backgroundColor = .white

    }
    
    
    @IBAction func signInBtnTapped(_ sender: Any) {
        let email = emailTextField.text ?? ""
        let password = passwordTextField.text ?? ""
        Auth.auth().signIn(withEmail: email, password: password) { (result, err) in
            if err != nil{
                self.showAlert(withMessage: err?.localizedDescription)
                return
            }
            guard let _ = result?.user else{return}
            self.moveToMessagesVC()
        }
    }
    
    func moveToMessagesVC(){
        let messagesVC:HomeViewController = UIStoryboard(storyboard: .Main, bundle: nil).controller()
        navigationController?.pushViewController(messagesVC, animated: true)
    }
    
    @IBAction func signupBtnTapped(_ sender: Any) {
        let signupVC:SignupViewController = UIStoryboard(storyboard: .Main, bundle: nil).controller()
        navigationController?.pushViewController(signupVC, animated: true)
    }
    
}
