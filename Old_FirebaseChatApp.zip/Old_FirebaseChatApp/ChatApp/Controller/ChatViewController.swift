//
//  ChatLogViewController.swift
//  ChatApp
//
//  Created by vamsi on 09/02/20.
//  Copyright © 2020 vamsi. All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage
import SVProgressHUD


class ChatViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var textView: UITextView!
    
    
    var imagepickerVC:ReusableImagePickerController!
    var imageUrl = ""
    var user = User()
    var messagesArray = [Messages]()
    var tempImage:UIImage?
    var isMessageEdited = false
    var editedIndexPath = IndexPath()
    var typeaMessage = "Type a message"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.tableFooterView = .init()
        navigationItem.title = user.name
        setupImagePickerController()
        observeMessages()
        setupPlaceholderTextView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.isNavigationBarHidden = false
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        SVProgressHUD.dismiss()
    }
    
    func setupImagePickerController(){
        self.imagepickerVC = ReusableImagePickerController(controller: self)
        imagepickerVC.delegate = self
        imagepickerVC.allowsEditing = false
        imagepickerVC.sourceType = .savedPhotosAlbum
    }
    
    func observeMessages() {
        SVProgressHUD.show(withStatus: "Loading messages...")
        messagesArray.removeAll()
        let uid = getCurrentUId
        let toId = user.uid
        let userMessagesRef = FirReference.userMessages.child(uid).child(toId)
        //This is only used to dismiss the loader
        userMessagesRef.observeSingleEvent(of: .value) { (dataSnapshot) in
            if !dataSnapshot.exists(){
                SVProgressHUD.dismiss()
                return
            }
        }
        //
        userMessagesRef.keepSynced(true)
        userMessagesRef.observe(.childAdded, with: { (snapshot) in
            if !snapshot.exists(){
                SVProgressHUD.dismiss()
                return
            }
            let messageId = snapshot.key
            let messagesRef = FirReference.messages.child(messageId)
            messagesRef.keepSynced(true)
            messagesRef.observeSingleEvent(of: .value, with: { (snapshot) in
                if !snapshot.exists(){
                    SVProgressHUD.dismiss()
                    return
                }
                guard let dictionary = snapshot.value as? [String: AnyObject] else {
                    SVProgressHUD.dismiss()
                    return
                }
                if let resp = try? JSONSerialization.data(withJSONObject: dictionary, options: .prettyPrinted){
                    if let reactionResp = try? JSONDecoder().decode(Messages.self, from: resp){
                        if reactionResp.chatPartnerId == self.user.uid {
                            self.messagesArray.append(reactionResp)
                            DispatchQueue.main.async{
                                SVProgressHUD.dismiss()
                                self.tableView.reloadData()
                                let indexPath = IndexPath(row: self.messagesArray.count-1, section: 0)
                                self.view.layoutIfNeeded()
                                self.tableView.scrollToRow(at: indexPath, at: .bottom, animated: true)
                            }
                        }
                    }else{
                        SVProgressHUD.dismiss()
                    }
                    
                }else{
                    SVProgressHUD.dismiss()
                }
            })
        })
    }
    
    @IBAction func uploadImage(_ sender: Any) {
        imagepickerVC.present()
    }
    
    @IBAction func handleSendbtn(_ sender: Any) {
        if textView.text == typeaMessage{
            textView.resignFirstResponder()
            return
        }
        if textView.text.trim.isEmpty && tempImage == nil{
            textView.resignFirstResponder()
            return
        }
        if isMessageEdited{
            sendEditedMessage()
        }else{
            
            if tempImage != nil{
                uploadImage { (imgUrl) in
                    self.sendMessage()
                }
            }else{
                sendMessage()
            }
        }
        self.isMessageEdited = false
        textView.resignFirstResponder()
    }
    
    
    func sendMessage(){
        let fromId = getCurrentUId
        let toId = self.user.uid
        let userName = self.user.name
        let sendTime = Double(Date().timeIntervalSince1970)
        let childRef = FirReference.messages.childByAutoId()
        let chatDict:[String:Any] = [
            "text":textView.text ?? "",
            "name":userName,
            "toId":toId,
            "fromId":fromId,
            "sendTime":sendTime,
            "imageUrl":self.imageUrl,
            "messageId":childRef.key ?? ""
        ]
        self.imageUrl = ""
        self.tempImage = nil
        self.setupPlaceholderTextView()
        textViewDidChange(textView)
        childRef.updateChildValues(chatDict) { (err, ref) in
            if err != nil{return}
            guard let messageId = childRef.key else { return }
            let userMessagesRef = FirReference.userMessages.child(fromId).child(toId).child(messageId)
            userMessagesRef.setValue(1)
            
            let receipientRef = FirReference.userMessages.child(toId).child(fromId).child(messageId)
            receipientRef.setValue(1)
            DispatchQueue.main.async{
                self.tableView.reloadData()
            }
        }
    }
    
    func sendEditedMessage(){
        let message = messagesArray[editedIndexPath.row]
        let chatDict  = ["text":textView.text ?? ""]
        FirReference.messages.child(message.messageId ?? "").updateChildValues(chatDict) { (err, ref) in
            if err != nil{
                print(err?.localizedDescription as Any)
                return
            }
            self.messagesArray[self.editedIndexPath.row].text = self.textView.text
            self.setupPlaceholderTextView()
            self.textViewDidChange(self.textView)
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
    func deleteMessage(_ indexPath:IndexPath){
        let message = messagesArray[indexPath.row]
        guard let chartPartnerId = message.chatPartnerId else{return}
        FirReference.userMessages.child(getCurrentUId).child(chartPartnerId).child(message.messageId ?? "").removeValue { (err, ref) in
            if err != nil{
                print(err?.localizedDescription as Any)
                return
            }
            self.messagesArray.remove(at: indexPath.row)
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
}

// MARK: - UITableViewDataSource

extension ChatViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messagesArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let message = messagesArray[indexPath.row]
        if message.fromId == getCurrentUId{
            let currentUserCell = tableView.dequeueReusableCell(withIdentifier: CurrentUserTableViewCell.reuseid, for: indexPath) as! CurrentUserTableViewCell
            currentUserCell.parentVC = self
            currentUserCell.configureCell(message)
            return currentUserCell
        }else{
            let receiverCell = tableView.dequeueReusableCell(withIdentifier: ReceiverTableViewCell.reuseid, for: indexPath) as! ReceiverTableViewCell
            receiverCell.parentVC = self
            receiverCell.configureCell(message, user: user)
            return receiverCell
        }
    }
}


// MARK: - UITableViewDelegate

extension ChatViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let message = messagesArray[indexPath.row]
        let edit = UIContextualAction(style: .normal, title: "Edit") { (action, view, nil) in
            self.editedIndexPath = indexPath
            self.isMessageEdited = true
            self.setupTypingTextView(str: message.text ?? "")
        }
        edit.backgroundColor = .green
        let delete = UIContextualAction(style: .destructive, title: "Delete") { (action, view, nil) in
            self.deleteMessage(indexPath)
        }
        return UISwipeActionsConfiguration(actions: [delete,edit])
    }
}

extension ChatViewController:ImagePickerDelegate{
    func didSelect(image: UIImage) {
        self.tempImage = image
    }
    
    func uploadImage(completion:@escaping((String))->()){
        guard let image = tempImage else { return}
        let randomImageName =  NSUUID().uuidString
        let storageRef = Storage.storage().reference().child("\(randomImageName).png")
        guard let imageData = image.jpegData(compressionQuality: 0.1) else {return  }
        storageRef.putData(imageData, metadata: nil, completion:
            {
                (metadata, error) in
                if error != nil {
                    print(error?.localizedDescription ?? "")
                    return
                }
                storageRef.downloadURL(completion: { (url, err) in
                    if let err = err {
                        print(err.localizedDescription)
                        return
                    }
                    guard let url = url else { return }
                    SVProgressHUD.dismiss()
                    self.imageUrl = url.absoluteString
                    completion(url.absoluteString)
                })
        })
    }
}

extension ChatViewController:UITextViewDelegate{
    
    func textViewDidChange(_ textView: UITextView) {
        let cgSize = CGSize(width: textView.frame.width, height: .infinity)
        let estimatedSize = textView.sizeThatFits(cgSize)
        if estimatedSize.height <= 145{
            textView.constraints.forEach { (constraint) in
                if constraint.firstAttribute == .height{
                    constraint.constant = estimatedSize.height
                }
            }
        }
    }
    
    func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        if textView.text == typeaMessage{
            setupTypingTextView()
        }
        return true
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if text == "\n" {
            textView.resignFirstResponder()
            return false
        }
        if textView.text == typeaMessage{
            setupTypingTextView()
        }
        return true
    }
    
    func setupPlaceholderTextView(){
        textView.font = UIFont.systemFont(ofSize: 15, weight: .light)
        textView.textColor = UIColor.label.withAlphaComponent(0.6)
        textView.text = typeaMessage
    }
    
    func setupTypingTextView(str:String = ""){
        textView.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        textView.textColor = .label
        textView.text = str
    }
}
