//
//  ProfileViewController.swift
//  ChatApp
//
//  Created by vamsi on 02/08/20.
//  Copyright © 2020 vamsi. All rights reserved.
//

import UIKit
import Firebase
import SVProgressHUD

class ProfileViewController: UIViewController {
    
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var editBtn: UIButton!
    
    
    var currentUserObj = User()
    var isEdited = false
    var imagepickerVC:ReusableImagePickerController!
    var imageUrl = ""
    var isUserPickedImage = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.isNavigationBarHidden = false
        getUserDetails()
        setupGestures()
    }
    
    func getUserDetails() {
        SVProgressHUD.show(withStatus: "Loading...")
        FirReference.usersRef.child(getCurrentUId).observeSingleEvent(of: .value) { (snapshot) in
            if let user = snapshot.value as? [String:AnyObject]{
                do{
                    let data = try JSONSerialization.data(withJSONObject: user, options: .fragmentsAllowed)
                    self.currentUserObj = try JSONDecoder().decode(User.self, from: data)
                    DispatchQueue.main.async {
                        SVProgressHUD.dismiss()
                        self.setupUI()
                    }
                }catch{
                    SVProgressHUD.dismiss()
                    print(error.localizedDescription)
                }
            }
        }
    }
    
    func setupUI(){
        tfUserInteraction(false)
        nameTextField.text = currentUserObj.name
        emailTextField.text = currentUserObj.email
        passwordTextField.text = currentUserObj.password ?? ""
        if currentUserObj.profilePic.isNotEmpty{
            let url = URL(string: currentUserObj.profilePic)
            self.profileImageView.sd_setImage(with: url, completed: nil)
        }else{
            self.profileImageView.isHidden = true
        }
    }
    
    func setupGestures(){
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleImageTap))
        profileImageView.isUserInteractionEnabled = false
        profileImageView.addGestureRecognizer(tapGesture)
        setupImagePickerController()
    }
    
    func setupImagePickerController(){
        self.imagepickerVC = ReusableImagePickerController(controller: self)
        imagepickerVC.delegate = self
        imagepickerVC.allowsEditing = false
        imagepickerVC.sourceType = .savedPhotosAlbum
    }
    
    @objc func handleImageTap(){
        imagepickerVC.present()
    }
    
    @IBAction func editBtnTapped(_ sender: UIButton) {
        isEdited.toggle()
        sender.setTitle(isEdited ? "Done" : "Edit", for: .normal)
        if isEdited{
            tfUserInteraction(true)
        }else{
            update()
            tfUserInteraction(false)
        }
    }
    
    func tfUserInteraction(_ bool:Bool){
        profileImageView.isUserInteractionEnabled = bool
        self.view.subviews.forEach { (view) in
            if view is UIStackView{
                view.subviews.forEach { (tf) in
                    tf.isUserInteractionEnabled = bool
                }
            }
        }
    }
    
    func update(){
        SVProgressHUD.show(withStatus: "updating..")
        if isUserPickedImage{
            uploadImage {
                self.sendToFirebase()
            }
        }else{
            sendToFirebase()
        }
    }
    
    
    func sendToFirebase(){
        SVProgressHUD.dismiss()
        let dict:[String : Any] = [
            "name":nameTextField.text ?? currentUserObj.name,
            "email":emailTextField.text ?? currentUserObj.email,
            "profilePic":isUserPickedImage ?  self.imageUrl : currentUserObj.profilePic,
            "password":passwordTextField.text ?? currentUserObj.password ?? ""
            ]
        FirReference.usersRef.child(currentUserObj.uid).updateChildValues(dict)
        navigationController?.popViewController(animated: true)
    }
    
    
    func uploadImage(completion:@escaping()->()){
        guard let image = profileImageView.image else { return}
        let randomImageName =  NSUUID().uuidString
        let storageRef = Storage.storage().reference().child("\(randomImageName).png")
        guard let imageData = image.jpegData(compressionQuality: 0.1) else {return  }
        storageRef.putData(imageData, metadata: nil, completion:
            {
                (metadata, error) in
                if error != nil {
                    print(error?.localizedDescription ?? "")
                    return
                }
                storageRef.downloadURL(completion: { (url, err) in
                    if let err = err {
                        print(err.localizedDescription)
                        return
                    }
                    guard let url = url else { return }
                    self.imageUrl = url.absoluteString
                    completion()
                })
        })
    }
}

extension ProfileViewController:ImagePickerDelegate{
    func didSelect(image: UIImage) {
        isUserPickedImage = true
        self.profileImageView.image = image
    }
    
    func didCancel() {
    }
}
