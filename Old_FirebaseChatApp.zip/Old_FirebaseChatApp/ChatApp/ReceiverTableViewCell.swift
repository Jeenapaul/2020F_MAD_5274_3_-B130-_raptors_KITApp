//
//  ReceiverTableViewCell.swift
//  ChatApp
//
//  Created by vamsi on 09/02/20.
//  Copyright © 2020 vamsi. All rights reserved.
//

import UIKit
import Lightbox

class ReceiverTableViewCell: UITableViewCell {
    
    @IBOutlet weak var imgViewTop: NSLayoutConstraint!
    @IBOutlet weak var imgViewHeight: NSLayoutConstraint!
    @IBOutlet weak var uploadedImgView: UIImageView!
    @IBOutlet weak var receiverImageView: UIImageView!
    @IBOutlet weak var receiverTextlbl: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var containerView: UIView!

    
    var parentVC:UIViewController?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        let tap = UITapGestureRecognizer(target: self, action: #selector(open))
        uploadedImgView.addGestureRecognizer(tap)
        uploadedImgView.isUserInteractionEnabled = true
    }
    
    func configureCell(_ message:Messages,user:User){
        containerView.backgroundColor = .systemOrange
        receiverTextlbl.text = message.text ?? ""
        if user.profilePic.isNotEmpty{
            let url = URL(string: user.profilePic)
            receiverImageView.sd_setImage(with: url, completed: nil)
        }
        let time = message.sendTime ?? 0.0
        let date = Date(timeIntervalSince1970: time)
        let dateFormatter = DateFormatter.defaultDateFormatter(.monthDateTimeWithout)
        timeLabel.text = dateFormatter.string(from: date)
        if let url = URL(string: message.imageUrl ?? ""){
            imgViewTop.constant = 10
            uploadedImgView.isHidden = false
            imgViewHeight.constant = 130
            uploadedImgView.sd_setImage(with: url)
        }else{
            imgViewTop.constant = 0
            uploadedImgView.isHidden = true
            imgViewHeight.constant = 0
        }
        if message.text?.isNotEmpty ?? false{
            imgViewTop.constant = uploadedImgView.isHidden ? 0 : 10
        }else{
            imgViewTop.constant = 10
        }
    }
    
    @objc func open(tapGestureRecognizer: UITapGestureRecognizer){
        let tappedImage = tapGestureRecognizer.view as! UIImageView
        var images: [LightboxImage] = []
        images.append(LightboxImage(image: tappedImage.image ?? UIImage()))
        // Create an instance of LightboxController.
        let controller = LightboxController(images: images)
        controller.modalPresentationStyle = .fullScreen
        // Set delegates.
        controller.pageDelegate = self
        controller.dismissalDelegate = self
        // Use dynamic background.
        controller.dynamicBackground = true
        parentVC?.present(controller, animated: true, completion: nil)
    }
    
}


extension ReceiverTableViewCell: LightboxControllerPageDelegate, LightboxControllerDismissalDelegate {
    func lightboxController(_ controller: LightboxController, didMoveToPage page: Int) {
        
    }
    func lightboxControllerWillDismiss(_ controller: LightboxController) {
        
    }
}

